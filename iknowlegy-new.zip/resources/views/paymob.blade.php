<iframe width="100%" height="800" src="https://accept.paymob.com/api/acceptance/iframes/40648?payment_token={{$token}}">
